import { MessageCircle } from 'lucide-react';

const WhatsAppButton = () => {
  const whatsappNumber = '971568403468';
  const defaultMessage = "Bonjour SMC Business, je souhaite avoir plus d'informations sur vos services.";
  
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(defaultMessage)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-float animate-pulse-gold"
      aria-label="Contactez-nous sur WhatsApp"
    >
      <MessageCircle size={28} className="text-white fill-white" />
    </a>
  );
};

export default WhatsAppButton;
