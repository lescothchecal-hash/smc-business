import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const goldBarRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const microLabelRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const bgImageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(overlayRef.current, { opacity: 0, scaleX: 0.98 });
      gsap.set(goldBarRef.current, { y: '-12vh', opacity: 0 });
      gsap.set(microLabelRef.current, { y: 24, opacity: 0 });
      gsap.set(headlineRef.current, { y: 40, opacity: 0 });
      gsap.set(subheadlineRef.current, { y: 24, opacity: 0 });
      gsap.set(ctaRef.current, { y: 20, opacity: 0 });

      // Load animation timeline
      const loadTl = gsap.timeline({ delay: 0.3 });

      loadTl
        .to(overlayRef.current, {
          opacity: 1,
          scaleX: 1,
          duration: 0.8,
          ease: 'power2.out',
        })
        .to(
          goldBarRef.current,
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: 'power3.out',
          },
          '-=0.4'
        )
        .to(
          microLabelRef.current,
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
          },
          '-=0.3'
        )
        .to(
          headlineRef.current,
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            ease: 'power2.out',
          },
          '-=0.4'
        )
        .to(
          subheadlineRef.current,
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
          },
          '-=0.4'
        )
        .to(
          ctaRef.current,
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            ease: 'power2.out',
          },
          '-=0.3'
        );

      // Scroll animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 3: EXIT (70%-100%)
      scrollTl
        .fromTo(
          contentRef.current,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          overlayRef.current,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          goldBarRef.current,
          { y: 0, opacity: 1 },
          { y: '-30vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          bgImageRef.current,
          { scale: 1 },
          { scale: 1.06, ease: 'none' },
          0.7
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-10"
    >
      {/* Background Image */}
      <div
        ref={bgImageRef}
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: 'url(/images/hero_dubai.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Dark Overlay Panel */}
      <div
        ref={overlayRef}
        className="absolute left-0 top-0 w-[62vw] h-full"
        style={{
          background:
            'linear-gradient(90deg, rgba(11,15,23,0.95) 0%, rgba(11,15,23,0.75) 70%, rgba(11,15,23,0) 100%)',
        }}
      />

      {/* Diagonal Gold Bar */}
      <div
        ref={goldBarRef}
        className="absolute left-[54vw] top-[18vh] w-[1.2vw] h-[64vh] bg-smc-gold"
        style={{ transform: 'skewY(-8deg)' }}
      />

      {/* Content */}
      <div
        ref={contentRef}
        className="absolute left-[8vw] top-[22vh] w-[40vw] max-w-[600px]"
      >
        {/* Micro Label */}
        <span ref={microLabelRef} className="micro-label block mb-6">
          SMC Business
        </span>

        {/* Headline */}
        <h1
          ref={headlineRef}
          className="heading-xl text-smc-light mb-6"
        >
          Vos Portes
          <br />
          <span className="text-smc-gold">Vers Dubaï</span>
        </h1>

        {/* Subheadline */}
        <p
          ref={subheadlineRef}
          className="text-lg md:text-xl text-smc-text-secondary mb-10 font-light"
        >
          Importation de véhicules · Électronique en gros · Voyages d'affaires
        </p>

        {/* CTA Buttons */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4">
          <a
            href="https://wa.me/971568403468?text=Bonjour%20SMC%20Business,%20je%20souhaite%20demander%20un%20devis."
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gold inline-flex items-center justify-center gap-2"
          >
            Demander un devis
            <ArrowRight size={16} />
          </a>
          <a
            href="#services"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="text-smc-text-secondary hover:text-smc-gold transition-colors text-sm font-medium inline-flex items-center justify-center gap-2"
          >
            Voir nos services
            <ArrowRight size={14} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
