import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Smartphone, Car, Plane } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Smartphone,
    title: 'Électronique en gros',
    description: 'Smartphones, accessoires, matériel pro.',
  },
  {
    icon: Car,
    title: 'Importation de véhicules',
    description: 'Neufs & occasions, documentation complète.',
  },
  {
    icon: Plane,
    title: 'Voyages & séjours',
    description: 'Business ou loisir, logement et assistance.',
  },
];

const ServicesOverview = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const goldBarRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%)
      scrollTl
        .fromTo(
          imageRef.current,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(
          goldBarRef.current,
          { y: '-20vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.05
        );

      // Cards stagger entrance
      cardRefs.current.forEach((card, index) => {
        if (card) {
          scrollTl.fromTo(
            card,
            { x: '-40vw', opacity: 0 },
            { x: 0, opacity: 1, ease: 'power2.out' },
            0.08 + index * 0.04
          );
        }
      });

      // Phase 3: EXIT (70%-100%)
      scrollTl
        .fromTo(
          cardsRef.current,
          { y: 0, opacity: 1 },
          { y: '-10vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          imageRef.current,
          { x: 0, opacity: 1 },
          { x: '12vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          goldBarRef.current,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.75
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="relative w-full h-screen overflow-hidden bg-smc-dark z-30"
    >
      {/* Service Cards - Left Side */}
      <div
        ref={cardsRef}
        className="absolute left-[8vw] top-[18vh] w-[34vw] max-w-[450px] space-y-4"
      >
        {services.map((service, index) => (
          <div
            key={service.title}
            ref={(el) => { cardRefs.current[index] = el; }}
            className="card-glass p-6 flex items-start gap-4 group hover:border-smc-gold/30 transition-all duration-300"
          >
            <div className="w-12 h-12 rounded-lg bg-smc-gold/10 flex items-center justify-center flex-shrink-0 group-hover:bg-smc-gold/20 transition-colors">
              <service.icon className="w-6 h-6 text-smc-gold" />
            </div>
            <div>
              <h3 className="font-sora font-semibold text-lg text-smc-light mb-1 group-hover:text-smc-gold transition-colors">
                {service.title}
              </h3>
              <p className="text-sm text-smc-text-secondary">
                {service.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Gold Diagonal Bar */}
      <div
        ref={goldBarRef}
        className="absolute left-[46vw] top-[22vh] w-[1vw] h-[56vh] bg-smc-gold"
        style={{ transform: 'skewY(-8deg)' }}
      />

      {/* Image Panel - Right Side */}
      <div
        ref={imageRef}
        className="absolute left-[50vw] top-[10vh] w-[44vw] h-[80vh] diagonal-clip-right overflow-hidden"
      >
        <img
          src="/images/services_port.jpg"
          alt="Port de commerce"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-smc-dark/40 to-transparent" />
      </div>
    </section>
  );
};

export default ServicesOverview;
