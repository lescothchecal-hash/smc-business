import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, MessageCircle, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    pays: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        formRef.current,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );

      gsap.fromTo(
        infoRef.current,
        { x: '6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        nom: '',
        email: '',
        telephone: '',
        pays: '',
        message: '',
      });
    }, 1500);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative w-full min-h-screen bg-smc-light z-[90]"
    >
      <div className="flex flex-col lg:flex-row">
        {/* Form Column */}
        <div
          ref={formRef}
          className="w-full lg:w-[46%] px-6 lg:px-12 py-16 lg:py-24"
        >
          <h2 className="heading-lg text-smc-dark mb-4">
            Parlons de Votre <span className="text-smc-gold">Projet</span>
          </h2>
          
          <p className="text-smc-text-dark mb-10 max-w-md">
            Remplissez le formulaire. Nous vous répondrons sous 24h avec une
            proposition concrète.
          </p>

          {submitted ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-sora font-semibold text-xl text-smc-dark mb-2">
                Message envoyé !
              </h3>
              <p className="text-smc-text-dark">
                Nous vous répondrons dans les plus brefs délais.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-smc-dark mb-2">
                  Nom
                </label>
                <Input
                  name="nom"
                  value={formData.nom}
                  onChange={handleChange}
                  placeholder="Votre nom complet"
                  required
                  className="bg-white border-smc-dark/20 text-smc-dark placeholder:text-smc-text-dark/50 focus:border-smc-gold focus:ring-smc-gold"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-smc-dark mb-2">
                  Email
                </label>
                <Input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="votre@email.com"
                  required
                  className="bg-white border-smc-dark/20 text-smc-dark placeholder:text-smc-text-dark/50 focus:border-smc-gold focus:ring-smc-gold"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-smc-dark mb-2">
                  Téléphone
                </label>
                <Input
                  name="telephone"
                  type="tel"
                  value={formData.telephone}
                  onChange={handleChange}
                  placeholder="+225 XX XX XX XX"
                  required
                  className="bg-white border-smc-dark/20 text-smc-dark placeholder:text-smc-text-dark/50 focus:border-smc-gold focus:ring-smc-gold"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-smc-dark mb-2">
                  Pays
                </label>
                <Select
                  value={formData.pays}
                  onValueChange={(value) =>
                    setFormData({ ...formData, pays: value })
                  }
                >
                  <SelectTrigger className="bg-white border-smc-dark/20 text-smc-dark focus:ring-smc-gold">
                    <SelectValue placeholder="Sélectionnez votre pays" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="burkina">Burkina Faso</SelectItem>
                    <SelectItem value="civ">Côte d'Ivoire</SelectItem>
                    <SelectItem value="ghana">Ghana</SelectItem>
                    <SelectItem value="autre">Autre</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-smc-dark mb-2">
                  Message
                </label>
                <Textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Décrivez votre projet..."
                  rows={4}
                  required
                  className="bg-white border-smc-dark/20 text-smc-dark placeholder:text-smc-text-dark/50 focus:border-smc-gold focus:ring-smc-gold resize-none"
                />
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-smc-gold hover:bg-smc-gold-light text-smc-dark font-sora font-semibold uppercase tracking-wider py-6 transition-all duration-300"
              >
                {isSubmitting ? 'Envoi en cours...' : 'Envoyer la demande'}
              </Button>
            </form>
          )}
        </div>

        {/* Info Column */}
        <div
          ref={infoRef}
          className="w-full lg:w-[54%] px-6 lg:px-12 py-16 lg:py-24 bg-smc-dark/5"
        >
          <div className="max-w-md">
            <h3 className="font-sora font-semibold text-xl text-smc-dark mb-8">
              Nos Coordonnées
            </h3>

            <div className="space-y-6 mb-10">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-smc-gold/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-smc-gold" />
                </div>
                <div>
                  <span className="block text-sm text-smc-text-dark mb-1">
                    Email
                  </span>
                  <a
                    href="mailto:contact@smcbusiness.ae"
                    className="text-smc-dark hover:text-smc-gold transition-colors"
                  >
                    contact@smcbusiness.ae
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-smc-gold/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-smc-gold" />
                </div>
                <div>
                  <span className="block text-sm text-smc-text-dark mb-1">
                    Téléphone
                  </span>
                  <a
                    href="tel:+971568403468"
                    className="text-smc-dark hover:text-smc-gold transition-colors"
                  >
                    +971 56 840 3468
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-smc-gold/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-smc-gold" />
                </div>
                <div>
                  <span className="block text-sm text-smc-text-dark mb-1">
                    Adresse
                  </span>
                  <span className="text-smc-dark">
                    Dubaï · Émirats Arabes Unis
                  </span>
                </div>
              </div>
            </div>

            {/* WhatsApp CTA */}
            <div className="bg-smc-dark rounded-xl p-6 mb-10">
              <div className="flex items-center gap-3 mb-4">
                <MessageCircle className="w-6 h-6 text-green-400" />
                <span className="font-sora font-semibold text-smc-light">
                  WhatsApp Direct
                </span>
              </div>
              <p className="text-smc-text-secondary text-sm mb-4">
                Réponse rapide garantie. Discutez directement avec notre équipe.
              </p>
              <a
                href="https://wa.me/971568403468?text=Bonjour%20SMC%20Business,%20je%20souhaite%20avoir%20plus%20d'informations."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-medium transition-colors"
              >
                <MessageCircle size={18} className="fill-white" />
                Écrire sur WhatsApp
              </a>
            </div>

            {/* Mini Map */}
            <div className="relative rounded-xl overflow-hidden h-48 border border-smc-dark/10">
              <img
                src="/images/hero_dubai.jpg"
                alt="Dubai"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-smc-dark/60 to-transparent" />
              <div className="absolute bottom-4 left-4">
                <span className="text-smc-light font-sora font-semibold">
                  Dubaï, EAU
                </span>
              </div>
              {/* Gold corner accent */}
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-smc-gold" />
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-smc-dark py-8 px-6 lg:px-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-sora font-bold text-xl text-smc-light">
              SMC<span className="text-smc-gold">.</span>
            </span>
            <span className="text-smc-text-secondary text-sm">
              © {new Date().getFullYear()} SMC Business. Tous droits réservés.
            </span>
          </div>
          <a
            href="#"
            className="text-smc-text-secondary hover:text-smc-gold text-sm transition-colors"
          >
            Mentions légales
          </a>
        </div>
      </footer>
    </section>
  );
};

export default Contact;
