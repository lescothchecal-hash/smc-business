import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote:
      "Service rapide et transparent. SMC a facilité l'import de notre premier lot de smartphones.",
    author: 'A. K.',
    role: 'Grossiste, Abidjan',
  },
  {
    quote:
      "Accompagnement du début à la fin. Les documents étaient conformes et l'arrivée du véhicule sans surprise.",
    author: 'M. S.',
    role: 'Entrepreneur, Ouagadougou',
  },
  {
    quote:
      "Voyage d'affaires organisé en 48h. Hôtel, transferts et rendez-vous : tout était structuré.",
    author: 'J. D.',
    role: 'Consultante, Accra',
  },
];

const Testimonials = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Cards stagger animation
      cardsRef.current.forEach((card, index) => {
        if (card) {
          gsap.fromTo(
            card,
            { y: 40, opacity: 0 },
            {
              y: 0,
              opacity: 1,
              duration: 0.7,
              delay: index * 0.12,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: sectionRef.current,
                start: 'top 75%',
              },
            }
          );

          // Subtle parallax
          gsap.to(card, {
            y: -24,
            ease: 'none',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            },
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-24 md:py-32 bg-smc-dark z-[80]"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="heading-lg text-smc-light text-center mb-16"
        >
          Ils Nous Font <span className="text-smc-gold">Confiance</span>
        </h2>

        {/* Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.author}
              ref={(el) => { cardsRef.current[index] = el; }}
              className="card-glass p-8 relative group hover:border-smc-gold/30 transition-all duration-300"
            >
              {/* Gold corner tick */}
              <div className="absolute top-6 left-6 w-6 h-[2px] bg-smc-gold" />
              
              {/* Quote icon */}
              <Quote className="w-8 h-8 text-smc-gold/30 mb-6" />
              
              {/* Quote text */}
              <p className="text-smc-light/90 text-sm leading-relaxed mb-8">
                "{testimonial.quote}"
              </p>
              
              {/* Author */}
              <div className="mt-auto">
                <span className="block font-sora font-semibold text-smc-gold">
                  {testimonial.author}
                </span>
                <span className="text-xs text-smc-text-secondary">
                  {testimonial.role}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
