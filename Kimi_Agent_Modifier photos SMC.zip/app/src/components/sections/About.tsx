import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const underlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);
  const goldTickRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%)
      scrollTl
        .fromTo(
          imageRef.current,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(
          goldTickRef.current,
          { opacity: 0, x: -20 },
          { opacity: 1, x: 0, ease: 'power2.out' },
          0.05
        )
        .fromTo(
          headlineRef.current,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.08
        )
        .fromTo(
          underlineRef.current,
          { scaleX: 0 },
          { scaleX: 1, ease: 'power2.out' },
          0.12
        )
        .fromTo(
          bodyRef.current,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.15
        )
        .fromTo(
          ctaRef.current,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.2
        );

      // Phase 3: EXIT (70%-100%)
      scrollTl
        .fromTo(
          textRef.current,
          { x: 0, opacity: 1 },
          { x: '-14vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          imageRef.current,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          underlineRef.current,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.75
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative w-full h-screen overflow-hidden bg-smc-dark z-20"
    >
      {/* Text Content - Left Side */}
      <div
        ref={textRef}
        className="absolute left-[8vw] top-[22vh] w-[38vw] max-w-[550px]"
      >
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="heading-lg text-smc-light mb-6"
        >
          Présents à Dubaï,
          <br />
          <span className="text-smc-gold">Au Service de l'Afrique</span>
        </h2>

        {/* Gold Underline */}
        <div
          ref={underlineRef}
          className="gold-underline w-[10vw] max-w-[120px] mb-8 origin-left"
        />

        {/* Body Text */}
        <p ref={bodyRef} className="body-text mb-10">
          SMC Business est implantée à Dubaï pour sécuriser chaque étape de votre
          importation. Nous accompagnons les entrepreneurs africains avec
          transparence, rapidité et un réseau local fiable.
        </p>

        {/* CTA */}
        <a
          ref={ctaRef}
          href="#services"
          onClick={(e) => {
            e.preventDefault();
            document.querySelector('#services')?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="btn-gold inline-flex items-center gap-2"
        >
          En savoir plus
          <ArrowRight size={16} />
        </a>
      </div>

      {/* Gold Tick */}
      <div
        ref={goldTickRef}
        className="absolute left-[50vw] top-[12vh] w-[3vw] h-[2px] bg-smc-gold"
        style={{ transform: 'rotate(-8deg)' }}
      />

      {/* Image Panel - Right Side */}
      <div
        ref={imageRef}
        className="absolute left-[52vw] top-[10vh] w-[42vw] h-[80vh] diagonal-clip-right overflow-hidden"
      >
        <img
          src="/images/about_dubai.jpg"
          alt="Dubai Business District"
          className="w-full h-full object-cover"
        />
        {/* Subtle overlay for cohesion */}
        <div className="absolute inset-0 bg-gradient-to-t from-smc-dark/40 to-transparent" />
      </div>
    </section>
  );
};

export default About;
