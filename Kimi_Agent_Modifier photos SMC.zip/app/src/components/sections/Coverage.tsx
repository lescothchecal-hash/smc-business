import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: '3', label: 'PAYS DÉSSERVIS' },
  { value: '48h', label: 'DÉLAI MOYEN' },
  { value: '100%', label: 'ACCOMPAGNEMENT' },
];

const Coverage = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const mapRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);
  const statValueRefs = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%)
      scrollTl
        .fromTo(
          mapRef.current,
          { x: '60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(
          headlineRef.current,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.08
        )
        .fromTo(
          bodyRef.current,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.12
        )
        .fromTo(
          statsRef.current,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.18
        )
        .fromTo(
          ctaRef.current,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.22
        );

      // Phase 3: EXIT (70%-100%)
      scrollTl
        .fromTo(
          textRef.current,
          { x: 0, opacity: 1 },
          { x: '-10vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          mapRef.current,
          { x: 0, opacity: 1 },
          { x: '12vw', opacity: 0, ease: 'power2.in' },
          0.7
        );

      // Counter animation for stats
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top 60%',
        onEnter: () => {
          statValueRefs.current.forEach((statEl, index) => {
            if (statEl) {
              const finalValue = stats[index].value;
              const isNumeric = !isNaN(parseInt(finalValue));
              
              if (isNumeric && !finalValue.includes('h')) {
                gsap.fromTo(
                  statEl,
                  { innerText: '0' },
                  {
                    innerText: finalValue,
                    duration: 1.5,
                    ease: 'power2.out',
                    snap: { innerText: 1 },
                  }
                );
              }
            }
          });
        },
        once: true,
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="coverage"
      className="relative w-full h-screen overflow-hidden bg-smc-dark z-[70]"
    >
      {/* Text Content - Left Side */}
      <div
        ref={textRef}
        className="absolute left-[8vw] top-[22vh] w-[38vw] max-w-[550px]"
      >
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="heading-lg text-smc-light mb-6"
        >
          Couverture Afrique
          <br />
          <span className="text-smc-gold">De l'Ouest</span>
        </h2>

        {/* Body Text */}
        <p ref={bodyRef} className="body-text mb-10">
          Expéditions régulières vers le Burkina Faso, la Côte d'Ivoire et le Ghana.
          Réseau de partenaires logistiques pour un suivi porte-à-porte.
        </p>

        {/* Stats */}
        <div ref={statsRef} className="flex gap-8 mb-10">
          {stats.map((stat, index) => (
            <div key={stat.label} className="text-center">
              <span
                ref={(el) => { statValueRefs.current[index] = el; }}
                className="block font-sora font-bold text-3xl md:text-4xl text-smc-gold mb-1"
              >
                {stat.value}
              </span>
              <span className="font-mono text-[10px] tracking-[0.12em] text-smc-text-secondary uppercase">
                {stat.label}
              </span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <a
          ref={ctaRef}
          href="https://wa.me/971568403468?text=Bonjour%20SMC%20Business,%20je%20souhaite%20connaître%20les%20itinéraires%20disponibles."
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold inline-flex items-center gap-2"
        >
          Voir les itinéraires
          <ArrowRight size={16} />
        </a>
      </div>

      {/* Map Graphic - Right Side */}
      <div
        ref={mapRef}
        className="absolute left-[56vw] top-[18vh] w-[36vw] h-[64vh]"
      >
        {/* West Africa Map SVG */}
        <svg
          viewBox="0 0 400 500"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Base map silhouette */}
          <path
            d="M50 50 L350 50 L350 450 L50 450 Z"
            fill="rgba(245,247,250,0.06)"
            stroke="rgba(245,247,250,0.1)"
            strokeWidth="1"
          />
          
          {/* Simplified West Africa outline */}
          <path
            d="M80 120 Q120 100 160 110 Q200 120 240 100 Q280 80 320 100 L340 150 Q350 200 330 250 Q310 300 320 350 Q330 400 300 430 Q250 450 200 440 Q150 430 100 450 Q70 420 60 370 Q50 320 70 270 Q90 220 80 170 Q70 140 80 120Z"
            fill="rgba(245,247,250,0.08)"
            stroke="rgba(245,247,250,0.15)"
            strokeWidth="1.5"
          />
          
          {/* Burkina Faso - Gold highlight */}
          <ellipse
            cx="180"
            cy="220"
            rx="35"
            ry="45"
            fill="rgba(212, 162, 58, 0.25)"
            stroke="#D4A23A"
            strokeWidth="2"
          />
          <text
            x="180"
            y="225"
            textAnchor="middle"
            fill="#D4A23A"
            fontSize="12"
            fontFamily="IBM Plex Mono"
            fontWeight="500"
          >
            BURKINA
          </text>
          
          {/* Côte d'Ivoire - Gold highlight */}
          <ellipse
            cx="120"
            cy="280"
            rx="30"
            ry="50"
            fill="rgba(212, 162, 58, 0.25)"
            stroke="#D4A23A"
            strokeWidth="2"
          />
          <text
            x="120"
            y="285"
            textAnchor="middle"
            fill="#D4A23A"
            fontSize="10"
            fontFamily="IBM Plex Mono"
            fontWeight="500"
          >
            CÔTE D'IVOIRE
          </text>
          
          {/* Ghana - Gold highlight */}
          <ellipse
            cx="160"
            cy="310"
            rx="25"
            ry="35"
            fill="rgba(212, 162, 58, 0.25)"
            stroke="#D4A23A"
            strokeWidth="2"
          />
          <text
            x="160"
            y="315"
            textAnchor="middle"
            fill="#D4A23A"
            fontSize="11"
            fontFamily="IBM Plex Mono"
            fontWeight="500"
          >
            GHANA
          </text>
          
          {/* Dubai indicator */}
          <circle
            cx="320"
            cy="80"
            r="8"
            fill="#D4A23A"
          />
          <text
            x="320"
            y="60"
            textAnchor="middle"
            fill="#F5F7FA"
            fontSize="11"
            fontFamily="IBM Plex Mono"
          >
            DUBAÏ
          </text>
          
          {/* Connection lines */}
          <path
            d="M320 88 Q250 150 200 200"
            stroke="#D4A23A"
            strokeWidth="1.5"
            strokeDasharray="5,5"
            fill="none"
            opacity="0.6"
          />
          <path
            d="M320 88 Q220 180 150 280"
            stroke="#D4A23A"
            strokeWidth="1.5"
            strokeDasharray="5,5"
            fill="none"
            opacity="0.6"
          />
          <path
            d="M320 88 Q240 200 170 310"
            stroke="#D4A23A"
            strokeWidth="1.5"
            strokeDasharray="5,5"
            fill="none"
            opacity="0.6"
          />
        </svg>
      </div>
    </section>
  );
};

export default Coverage;
