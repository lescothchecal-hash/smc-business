import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ServiceVehicles = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const underlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const bulletsRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);
  const goldBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Phase 1: ENTRANCE (0%-30%)
      scrollTl
        .fromTo(
          imageRef.current,
          { x: '-60vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(
          goldBarRef.current,
          { y: '-20vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.05
        )
        .fromTo(
          headlineRef.current,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.08
        )
        .fromTo(
          underlineRef.current,
          { scaleX: 0 },
          { scaleX: 1, ease: 'power2.out' },
          0.12
        )
        .fromTo(
          bodyRef.current,
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.15
        )
        .fromTo(
          bulletsRef.current,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.18
        )
        .fromTo(
          ctaRef.current,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0.22
        );

      // Phase 3: EXIT (70%-100%)
      scrollTl
        .fromTo(
          textRef.current,
          { x: 0, opacity: 1 },
          { x: '14vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          imageRef.current,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          goldBarRef.current,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.75
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden bg-smc-dark z-50"
    >
      {/* Image Panel - Left Side */}
      <div
        ref={imageRef}
        className="absolute left-[6vw] top-[10vh] w-[42vw] h-[80vh] diagonal-clip-left overflow-hidden"
      >
        <img
          src="/images/vehicles_luxury.jpg"
          alt="Véhicules de luxe"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-smc-dark/40 to-transparent" />
      </div>

      {/* Gold Diagonal Bar */}
      <div
        ref={goldBarRef}
        className="absolute left-[48vw] top-[22vh] w-[1vw] h-[56vh] bg-smc-gold"
        style={{ transform: 'skewY(-8deg)' }}
      />

      {/* Text Content - Right Side */}
      <div
        ref={textRef}
        className="absolute left-[54vw] top-[22vh] w-[38vw] max-w-[550px]"
      >
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="heading-lg text-smc-light mb-6"
        >
          Importation de
          <br />
          <span className="text-smc-gold">Véhicules</span>
        </h2>

        {/* Gold Underline */}
        <div
          ref={underlineRef}
          className="gold-underline w-[10vw] max-w-[120px] mb-8 origin-left"
        />

        {/* Body Text */}
        <p ref={bodyRef} className="body-text mb-6">
          Neufs ou occasions, citadines ou utilitaires. Contrôle qualité, documents
          conformes, livraison jusqu'au port de destination.
        </p>

        {/* Bullets */}
        <div ref={bulletsRef} className="mb-8">
          <span className="font-mono text-xs tracking-[0.12em] text-smc-gold uppercase">
            Berlines · 4×4 · Utilitaires · Hybrides
          </span>
        </div>

        {/* CTA */}
        <a
          ref={ctaRef}
          href="https://wa.me/971568403468?text=Bonjour%20SMC%20Business,%20je%20souhaite%20voir%20les%20véhicules%20disponibles."
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold inline-flex items-center gap-2"
        >
          Voir les disponibilités
          <ArrowRight size={16} />
        </a>
      </div>
    </section>
  );
};

export default ServiceVehicles;
