import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import './App.css';

// Components
import Navbar from './components/Navbar';
import WhatsAppButton from './components/WhatsAppButton';

// Sections
import Hero from './components/sections/Hero';
import About from './components/sections/About';
import ServicesOverview from './components/sections/ServicesOverview';
import ServiceElectronics from './components/sections/ServiceElectronics';
import ServiceVehicles from './components/sections/ServiceVehicles';
import ServiceTravel from './components/sections/ServiceTravel';
import Coverage from './components/sections/Coverage';
import Testimonials from './components/sections/Testimonials';
import Contact from './components/sections/Contact';

gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    // Wait for all ScrollTriggers to be created
    const timeout = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter((st) => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map((st) => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Global snap configuration
      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (with buffer)
            const inPinned = pinnedRanges.some(
              (r) => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            
            if (!inPinned) return value; // Flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );

            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timeout);
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  return (
    <div className="relative">
      {/* Noise Overlay */}
      <div className="noise-overlay" />

      {/* Navigation */}
      <Navbar />

      {/* Main Content */}
      <main className="relative">
        {/* Section 1: Hero - z-10 */}
        <Hero />

        {/* Section 2: About - z-20 */}
        <About />

        {/* Section 3: Services Overview - z-30 */}
        <ServicesOverview />

        {/* Section 4: Service Electronics - z-40 */}
        <ServiceElectronics />

        {/* Section 5: Service Vehicles - z-50 */}
        <ServiceVehicles />

        {/* Section 6: Service Travel - z-60 */}
        <ServiceTravel />

        {/* Section 7: Coverage - z-70 */}
        <Coverage />

        {/* Section 8: Testimonials - z-80 */}
        <Testimonials />

        {/* Section 9: Contact - z-90 */}
        <Contact />
      </main>

      {/* WhatsApp Floating Button */}
      <WhatsAppButton />
    </div>
  );
}

export default App;
